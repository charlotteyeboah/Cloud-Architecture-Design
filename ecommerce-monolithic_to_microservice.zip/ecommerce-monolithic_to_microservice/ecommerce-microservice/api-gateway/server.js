const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");

const app = express();

// Proxy API endpoints
app.use("/user", createProxyMiddleware({
  target: "http://user-service:4001",
  changeOrigin: true,
  pathRewrite: { "^/user": "" },
}));

app.use("/products", createProxyMiddleware({
  target: "http://product-service:4002",
  changeOrigin: true,
  pathRewrite: { "^/products": "/products" }, // 👈 sends it to /products
}));

// Proxy Swagger UI pages
app.use("/docs/user", createProxyMiddleware({
  target: "http://user-service:4001/api-docs",
  changeOrigin: true,
  pathRewrite: { "^/docs/user": "" },
}));

app.use("/docs/product", createProxyMiddleware({
  target: "http://product-service:4002/api-docs",
  changeOrigin: true,
  pathRewrite: { "^/docs/product": "" },
}));

app.get("/", (req, res) => {
  res.send("API Gateway is running");
});

app.listen(4000, () => {
  console.log("API Gateway running on port 4000");
});
